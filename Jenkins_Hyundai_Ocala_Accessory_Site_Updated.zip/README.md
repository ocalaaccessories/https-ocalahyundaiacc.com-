# Jenkins Hyundai of Ocala Accessory Website

A static, single-page accessory and protection quote builder designed for GitHub Pages. It does not require a server, database, build process, or third-party JavaScript libraries.

## Included files

- `index.html` — the complete website
- `assets/jenkins-hyundai-ocala-logo.png` — dealership logo used in the header, quote, and footer
- `assets/hyundai-mark-blue.png` — Hyundai mark used on the printed/customer quote
- `assets/favicon.png` — browser-tab icon
- `accessories.csv` — editable reference copy of the accessory list
- `README.md` — setup and operating notes

Keep the `assets` folder beside `index.html`. The logo paths in the website are relative to that folder.

## Main features

- Branded Jenkins Hyundai of Ocala header, customer quote, footer, and favicon
- Four-step workflow: Deal Info, Products, Packages, Summary
- Vehicle-specific fitment filtering
- Search and category filters
- Good / Better / Best package builder
- Editable package discounts
- Editable tax rate, finance term, APR, and cash-deal mode
- Editable product prices saved locally in each browser
- Customer and sales-associate signature pads
- Print-friendly final quote
- Responsive desktop, tablet, and mobile layout
- No customer data is transmitted; quote data remains in the current browser session

## Important pricing note

The imported source document labels the amount column **Parts Cost**. Before using this website with customers, confirm whether each amount should be presented as a retail price, installed price, parts-only price, or internal cost. Product amounts can be changed from the Settings button in the website. Browser changes are local to that device.

To permanently change a default amount for every device, edit the `DEFAULT_PRODUCTS` array near the bottom of `index.html`.

## Publish with GitHub Pages

1. Create or open the GitHub repository used for the accessory website.
2. Upload `index.html`, the complete `assets` folder, `accessories.csv`, and `README.md` to the repository root.
3. In GitHub, open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide the live Pages URL after deployment.

When updating an existing site, replace the old `index.html` and upload the new `assets` folder without changing the folder or file names.

## Operational notes

- Finance and price settings use browser `localStorage` and remain on that specific browser until cleared.
- Customer details and the current quote use `sessionStorage` and normally clear when the browser tab/session ends.
- Signatures are not stored after a page refresh.
- The website is an estimating and presentation tool, not a payment processor or credit application.
